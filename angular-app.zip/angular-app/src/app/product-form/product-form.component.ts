import { Component, EventEmitter, Output } from '@angular/core';
import { Product } from '../Product';

@Component({
  selector: 'app-product-form',
  templateUrl: './product-form.component.html',
  styleUrls: ['./product-form.component.css']
})
export class ProductFormComponent {

  @Output() addProduct=new EventEmitter()
  product:Product|null=null
  onSubmit() {
    this.addProduct.emit(this.productForm.value);
  }

  productForm: any;

}
