import { Component } from '@angular/core';
import { map, Observable, of } from 'rxjs';
import { Product } from '../Product';
import { ProductService } from '../product-service.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent {


  products$!: Observable<Product[]>;
  filterdProducts$!: Observable<Product[]>;
  products: Product[] = [];

  constructor(private service: ProductService) { }


  ngOnInit() {

    this.products$ = this.service.getProducts();
  }

  addProduct(newProduct: any) {
    this.service.addProduct(newProduct);
  }

  searchProducts(event: any) {

    this.filterdProducts$ = this.service.getProducts().pipe(
      map((products) => products.filter((a: { productName: any; }) => a.productName === event.target.value))
    );

  }


}






