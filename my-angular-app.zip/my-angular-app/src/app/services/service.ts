import { Injectable } from '@angular/core';
//import { HttpClient } from '@angular/common/http';
import { Employee } from '../models/employee.model';
import { Observable, tap } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
    private apiUrl="";
    constructor(private http:HttpClient){}

     addEmpolyee(employee:Employee):Observable<Employee>{
        return this.http.post<Employee>(`${this.apiUrl}`,employee)
    }
    getAllEmployees():Observable<Employee[]>{
        return this.http.get<Employee[]>(`${this.apiUrl}`)
    }
    getEmployeeById(id:string):Observable<Employee[]>{
        return this.http.get<Employee[]>(`${this.apiUrl}?employeeId=${id}`);
    }
}
