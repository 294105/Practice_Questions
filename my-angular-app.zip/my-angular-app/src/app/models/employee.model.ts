export interface Employee{
    id:string,
    employeeId:string,
    employeeName:string,
    employeeEmail:string,
    salary:number,
    department:string
}