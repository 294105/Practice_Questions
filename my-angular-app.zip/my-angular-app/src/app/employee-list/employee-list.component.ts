import { Component, OnInit } from '@angular/core';
import { Employee } from '../models/employee.model';
import { EmployeeService } from '../services/employee.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit{
  employees: Employee[] = [];
  public employee:Employee|null =null;
  public id:string='';

  public isEditing: boolean = false;
  public editEmployee: Employee | null = null;

  constructor(private employeeService:EmployeeService) { }

  ngOnInit(): void {
    this.employeeService.getEmployees().subscribe(data => {
      this.employees = data;
      
    });
  }
  getByEmployeeId():void{
    this.employeeService.getEmployeeById(this.id).subscribe((res)=>{
        this.employee=res[0];
        //console.log(res.id);
    });
  }

  deleteEmployeeById(id:string){
    
    
    this.employeeService.deleteEmployeeById(id).subscribe((res)=>{
      console.log(res);
      this.ngOnInit();
    })
     
    
  }
  
  onEdit(emp: Employee) {
    this.editEmployee = { ...emp }; 
    this.isEditing = true;
  }

  updateEmployee() {
    if (this.editEmployee) {
      this.employeeService.updateEmployeeById(this.editEmployee.id, this.editEmployee).subscribe(updatedEmp => {
        console.log('Employee updated:', updatedEmp);
        this.isEditing = false;
        this.editEmployee = null;
        this.ngOnInit();
      }, error => {
        console.error('Update failed', error);
      });
    }
  }

  cancelEdit() {
    this.isEditing = false;
    this.editEmployee = null;
  }

}
