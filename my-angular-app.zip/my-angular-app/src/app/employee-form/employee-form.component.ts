import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { EmployeeService } from '../services/employee.service';
import { Employee } from '../models/employee.model';

@Component({
  selector: 'app-employee-form',
  templateUrl: './employee-form.component.html',
  styleUrls: ['./employee-form.component.css']
})
export class EmployeeFormComponent {
     public form:FormGroup;
     public print1:boolean=false;
     constructor(public formBuilder:FormBuilder,private employeeService:EmployeeService){
      this.form=this.formBuilder.group({
        employeeId:['',Validators.required],
        employeeName:['',Validators.required],
        employeeEmail:['',[Validators.required,Validators.email]],
        salary:['',[Validators.required,Validators.min(0)]],
        department:['',Validators.required]
      });
      

     }

    onSubmit(){
     
      this.form.markAllAsTouched();
      if(this.form.valid){ this.print1=true
        const newEmp:Employee=this.form.value;
        this.employeeService.addEmployee(newEmp).subscribe((res)=>{
          console.log(`Employee Added `,res);
           this.print1=false
          this.form.reset();
        })
      }
    }
}
